# Java Servlet sample

## Пошаговое объяснение Java сервлетов

Этот репозиторий - дополнение к плейлисту на YouTube:
[Введение в Java сервлеты (русский язык)](https://www.youtube.com/watch?v=Jnd4PQt44j0&list=PLU2ftbIeotGoQGD51e0qb98lE0xhgNDF1)

## Sample step-by-step explanation of Java Servlet

This repository is associated with the following YouTube playlist:
[Introduction to Java Servlet (Russian)](https://www.youtube.com/watch?v=Jnd4PQt44j0&list=PLU2ftbIeotGoQGD51e0qb98lE0xhgNDF1)
